tinyMCE.addI18n('en.imgmanager_dlg',{
missing_alt: "Are you sure you want to continue without including Alternate Text for the image? Without it the image may not be accessible to some users with disabilities, or to those using a text browser, or browsing the Web with images turned off.",
delta_width: 0,
delat_height: 0,
no_src: 'A URL is required. Please select an image or enter a URL'
});